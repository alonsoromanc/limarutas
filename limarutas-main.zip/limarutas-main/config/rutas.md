# Formales

Código ATU, Nombre/Alias, Empresa Operadora, Origen (Distrito), Destino (Distrito), Calles Principales, Tipo Autorización, Fecha Autorización, Flota Vehicular
1003, "La 9", ET. Rosa de las Américas S.A.C. (ETROASAC), Puente Piedra, Rímac, N/D, ATU (Formal), 2025, N/D
1004, (sin alias), ET. Doce de Junio S.A. (ETDOJUSA), Comas, San Martín de Porres, N/D, ATU (Formal), 2025, N/D
1005, "La 13", Transp. y Serv. Santa Cruz S.A., Carabayllo, Rímac, N/D, ATU (Formal), 2025, N/D
1006, "La C", ET. Impulsa Progreso S.A.C., Carabayllo, Ate, N/D, ATU (Formal), 2025, N/D
1007, "La 87B", ET. y Serv. Amancaes S.A. (ETAMSA), Puente Piedra, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1008, "La 03", Grupo Express del Perú S.A.C. / Realidad Express 03 S.A.C., Carabayllo, Magdalena del Mar, N/D, ATU (Formal), 2025, N/D
1009, "La 06", ET. Unidos Punchauca S.A. (ETCIPSA), Carabayllo, San Miguel, N/D, ATU (Formal), 2025, N/D
1010, "La 46B", ET. Mariscal Ramón Castilla S.A. (ETMRCSA), Puente Piedra, Magdalena del Mar, N/D, ATU (Formal), 2025, N/D
1011, "La 47", Translima S.A., Carabayllo, Pueblo Libre, N/D, ATU (Formal), 2025, N/D
1012, "La B", E. Serv. Transp. Unión Nacional S.A.C. (ESTUNSAC), Carabayllo, San Miguel, N/D, ATU (Formal), 2025, N/D
1013, "La 18", Translima S.A., Carabayllo, Jesús María, N/D, ATU (Formal), 2025, N/D
1014, (sin alias), ET. 14 de Diciembre S.A.C., Comas, San Luis, N/D, ATU (Formal), 2025, N/D
1015, "La MG", ET. Miguel Grau S.A. (ETMIGRASA), Carabayllo, Lince, N/D, ATU (Formal), 2025, N/D
1016, (sin alias), ET. La Buena Estrella S.A.C. / Corp. Las Estrellas S.A.C., Ancón, La Victoria, N/D, ATU (Formal), 2025, N/D
1017, (sin alias), Novobus S.A.C. / Corp. Las Estrellas S.A.C., Ancón, La Victoria, N/D, ATU (Formal), 2025, N/D
1018, (sin alias), ET. Once de Noviembre S.A. (EMPTONSA), Carabayllo, La Victoria, N/D, ATU (Formal), 2025, N/D
1019, "La P", ET. Palmari S.A. / Gr. Empresarial El Rápido S.A., Puente Piedra, Magdalena del Mar, N/D, ATU (Formal), 2025, N/D
1020, "La C", ET. Santa Luzmila S.A. (ETSLUSA), Puente Piedra, Miraflores, N/D, ATU (Formal), 2025, N/D
1021, "La F", Inversiones & Serv. CKF S.A. / Gr. El Rápido S.A., Carabayllo, Lince, N/D, ATU (Formal), 2025, N/D
1022, (sin alias), Trans. Norcom Corporation S.A.C. / Gr. El Rápido S.A., Carabayllo, Miraflores, N/D, ATU (Formal), 2025, N/D
1023, "La B", ET. Nueva América S.A. (TRANSNASA), Carabayllo, Lince, N/D, ATU (Formal), 2025, N/D
1024, "La U / La A / La B / La C", ET. Nor Lima S.A. (ETNOLSA), San Martín de Porres, San Martín de Porres, N/D, ATU (Formal), 2025, N/D
1025, "La 73B", ET. Unidos de Pasajeros S.A. (ETUPSA), San Martín de Porres, Rímac, N/D, ATU (Formal), 2025, N/D
1026, "La S2", ET. Especial Solidaridad S.A. (EMTESSA), San Martín de Porres, Rímac, N/D, ATU (Formal), 2025, N/D
1027, "La 100", Coop. Tte. Comité Cien Ltda., Rímac, Ate, N/D, ATU (Formal), 2025, N/D
1028, "La B", ET. Pacific International S.A. (ETRASERPISA), San Martín de Porres, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1029, (sin alias), ET. Alipio Ponce Vásquez S.A. (ETALPOVASA), Independencia, San Miguel, N/D, ATU (Formal), 2025, N/D
1030, (sin alias), ET. Corazón de Jesús de San Diego S.A., San Martín de Porres, San Martín de Porres, N/D, ATU (Formal), 2025, N/D
1031, "La 29", Translima S.A., San Martín de Porres, Jesús María, N/D, ATU (Formal), 2025, N/D
1032, "La A", ET. San Juan de La Cruz S.A.C. / Translicsa, San Martín de Porres, La Victoria, N/D, ATU (Formal), 2025, N/D
1033, "La C", ET. De Luxe S.A.C., San Martín de Porres, La Victoria, N/D, ATU (Formal), 2025, N/D
1034, "La 36", E.I.T.S.A. (Emp. Indep. de Ttes. S.A.), Rímac, La Victoria, N/D, ATU (Formal), 2025, N/D
1035, (sin alias), ET. Esp. La Bala S.A., Rímac, La Victoria, N/D, ATU (Formal), 2025, N/D
1036, (sin alias), ET. El Bajopontino S.A., Rímac, La Victoria, N/D, ATU (Formal), 2025, N/D
1037, "La B", Translicsa (Lima Chorrillos S.A.), San Martín de Porres, La Victoria, N/D, ATU (Formal), 2025, N/D
1038, "La 28 / La 504", ET. El Porvenir S.A. (ETEPSA), San Martín de Porres, Lince, N/D, ATU (Formal), 2025, N/D
1039, "La 117", ET. 117 S.A. (ETSEDISA), Independencia, Callao, N/D, ATU (Formal), 2025, N/D
1040, "La SC / La San Ignacio", ET. San Ignacio S.A. (ETSISA), San Juan de Lurigancho, Rímac, N/D, ATU (Formal), 2025, N/D
1041, (sin alias), ET. Sta Rosa de Jicamarca S.A. (ETSRJSA), San Juan de Lurigancho, Chaclacayo, N/D, ATU (Formal), 2025, N/D
1042, "La 75A", ET. Las Águilas 75 S.A. (ETLA75SA), San Juan de Lurigancho, Ate, N/D, ATU (Formal), 2025, N/D
1043, "La 40", ET. Cuarenta Integrada S.A. (ETRANCISA), San Juan de Lurigancho, La Molina, N/D, ATU (Formal), 2025, N/D
1044, "La 104", Transp. & Serv. 104 S.A.C., San Juan de Lurigancho, Jesús María, N/D, ATU (Formal), 2025, N/D
1045, "La R-I", ET. El Lobito S.A.C., San Juan de Lurigancho, Lince, N/D, ATU (Formal), 2025, N/D
1046, "La 52C", ET. Unidos S.A. (ETUSA), San Juan de Lurigancho, Magdalena del Mar, N/D, ATU (Formal), 2025, N/D
1047, (sin alias), Trans. Sabino S.A.C. (TRANSSABISAC), San Juan de Lurigancho, Lince, N/D, ATU (Formal), 2025, N/D
1048, "La 10A", ET. Santo Cristo de Pachacamilla S.A., San Juan de Lurigancho, Miraflores, N/D, ATU (Formal), 2025, N/D
1049, (sin alias), ET. 12 de Enero S.A. (ETDESA), San Juan de Lurigancho, Lince, N/D, ATU (Formal), 2025, N/D
1050, "La R-1", ET. El Lobito S.A.C., San Juan de Lurigancho, Lince, N/D, ATU (Formal), 2025, N/D
1051, "La 52J", ET. Unidos S.A. (ETUSA), San Juan de Lurigancho, San Isidro, N/D, ATU (Formal), 2025, N/D
1052, "La HA", ET. HA de Serv. Múlt. Prop. Unidos Huáscar S.A., San Juan de Lurigancho, S.J. de Miraflores, N/D, ATU (Formal), 2025, N/D
1053, "La H", ET. Sur Lima S.A., San Juan de Lurigancho, Chorrillos, N/D, ATU (Formal), 2025, N/D
1054, "La E", ET. Urbano Línea 4 S.A. (ETUL4SA), San Juan de Lurigancho, Chorrillos, N/D, ATU (Formal), 2025, N/D
1055, "La 31", Transportes Lima Urban Company S.A., San Juan de Lurigancho, Chorrillos, N/D, ATU (Formal), 2025, N/D
1056, "La P", ET. & Serv. Arco Iris S.A. (ETSAISA), San Juan de Lurigancho, Villa El Salvador, N/D, ATU (Formal), 2025, N/D
1057, "La 23C", E. Serv. Transp. Santa Catalina S.A., San Juan de Lurigancho, Villa María del Triunfo, N/D, ATU (Formal), 2025, N/D
1058, "La R28", Transportes Huáscar S.A., San Juan de Lurigancho, Lurín, N/D, ATU (Formal), 2025, N/D
1059, "La 23B", E. Serv. Transp. Santa Catalina S.A. (ESTSACASA), San Juan de Lurigancho, Villa María del Triunfo, N/D, ATU (Formal), 2025, N/D
1060, "La 8", ET. & Serv. Ocho S.A. (ETSOSA), San Juan de Lurigancho, Villa María del Triunfo, N/D, ATU (Formal), 2025, N/D
1061, "La M1", ET. Pref. M1 S.A. (ETSPM1SA), San Juan de Lurigancho, Villa El Salvador, N/D, ATU (Formal), 2025, N/D
1062, "La M1", ET. Los Cuatro Suyos S.A., San Juan de Lurigancho, Villa El Salvador, N/D, ATU (Formal), 2025, N/D
1063, "La M", ET. Los Magníficos S.A. / Transp. Neg. Santa Anita S.A., San Juan de Lurigancho, Pachacámac, N/D, ATU (Formal), 2025, N/D
1064, "La 49", ET. Santa Rosa de Jicamarca S.A. (ETSRJSA), Lurigancho/Chosica, San Juan de Lurigancho, N/D, ATU (Formal), 2025, N/D
1065, "La 91", ET. Nuevo Horizonte S.A. (ETNHOSA), Ate, Ate, N/D, ATU (Formal), 2025, N/D
1066, "La HCT – El Huaycanero", ET. y Turismo Huaycán S.A. (ETRANTURHSA), Huaycán (Lurigancho), Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1067, (sin alias), ET. Peralitos S.A., Santa Anita, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1068, "La HGK – El Huaycanero", Serv. Múlt. Nuevo Perú S.A., Huaycán, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1069, "El Chosicano", ET. Nueva Era Señor de Muruhuay S.A., Ricardo Palma (Huarochirí), Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1070, (sin alias), ET. Bronco S.A. (ETBRONSA), Ate, Jesús María, N/D, ATU (Formal), 2025, N/D
1071, "La IC", Multiserv. & Inversions Virgen de Copacabana S.A.C., Ate, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1072, (sin alias), ET. Unidos San Martín de Porres S.A. (ETUSMPSA), Ate, La Victoria, N/D, ATU (Formal), 2025, N/D
1073, "La B", ET. Ntra. Sra. del Sagrado Corazón S.A., Ate, San Isidro, N/D, ATU (Formal), 2025, N/D
1074, "La B / La 112", ET. Miraflores Monterrico S.A. (ETMIMSA), Ate, San Isidro, N/D, ATU (Formal), 2025, N/D
1075, "La 51", ET. San Juan Bautista S.A., Lurigancho/Chosica, La Victoria, N/D, ATU (Formal), 2025, N/D
1076, (sin alias), ET. 14 de Mayo S.A.C., Huaycán, La Victoria, N/D, ATU (Formal), 2025, N/D
1077, (sin alias), Transp. Perla de los Andes S.A.C., Huaycán, La Victoria, N/D, ATU (Formal), 2025, N/D
1078, "La 63", ET. Sesentitrés S.A., Ate, La Victoria, N/D, ATU (Formal), 2025, N/D
1079, (sin alias), ET. Unidos San Martín de Porres S.A. (ETUSMPSA), Ate, La Victoria, N/D, ATU (Formal), 2025, N/D
1080, "La HCT – El Huaycanero", ET. y Turismo Huaycán S.A. (ETRANTURHSA), Huaycán, La Victoria, N/D, ATU (Formal), 2025, N/D
1081, (sin alias), ET. Urbano Huaycán S.A., Huaycán, La Victoria, N/D, ATU (Formal), 2025, N/D
1082, (sin alias), ET. Angamos S.A., Ate, Miraflores, N/D, ATU (Formal), 2025, N/D
1083, (sin alias), Transp. e Inversiones Sin Fronteras S.A.C., Huaycán, La Victoria, N/D, ATU (Formal), 2025, N/D
1084, "La 91", ET. Consorcio Santo Cristo S.A., Ate, Chorrillos, N/D, ATU (Formal), 2025, N/D
1085, (sin alias), EMTRACACE (Turismo Carretera Central S.A.C.), Lima (Cercado), Santa Eulalia (Huarochirí), N/D, ATU (Formal), 2025, N/D
1086, (sin alias), ET. Magdalena–San Miguel S.A. (ETRAMSMSA), San Borja, Callao, N/D, ATU (Formal), 2025, N/D
1087, "La 52T", ET. Unidos S.A. (ETUSA), Chorrillos, Jesús María, N/D, ATU (Formal), 2025, N/D
1088, (sin alias), SGTT Renacimiento S.A., Chorrillos, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1089, "La 24", ATCRSA (Ttes. en Camionetas S.A.), San Juan de Miraflores, Lince, N/D, ATU (Formal), 2025, N/D
1090, "La C", ET. Unidos Chama S.A., Chorrillos, San Isidro, N/D, ATU (Formal), 2025, N/D
1091, "La 160", ET. Múltiples 160 S.A.C., San Juan de Miraflores, La Victoria, N/D, ATU (Formal), 2025, N/D
1092, (sin alias), ET. San Genaro S.A. (ETSEMUSAGESA), Chorrillos, La Victoria, N/D, ATU (Formal), 2025, N/D
1093, "La I", ET. Sur 1° de Junio S.A.C. (ETPRIJUSAC), San Juan de Miraflores, San Isidro, N/D, ATU (Formal), 2025, N/D
1094, "La C", ET. Unidos 12 de Noviembre S.A. (ETUNOSA), San Juan de Miraflores, Miraflores, N/D, ATU (Formal), 2025, N/D
1095, "La 57", ET. N. América S.A.C., Chorrillos, Miraflores, N/D, ATU (Formal), 2025, N/D
1096, "La B – La Banchero", ET. Luis Banchero Rossi S.A. (LUBARSA), Villa El Salvador, San Juan de Lurigancho, N/D, ATU (Formal), 2025, N/D
1097, "La 10E", ET. Santo Cristo de Pachacamilla S.A., Villa El Salvador, San Juan de Lurigancho, N/D, ATU (Formal), 2025, N/D
1098, "La 08 – La L", ET. Urbano Línea 4 S.A. (ETUL4SA), Lurín, San Juan de Lurigancho, N/D, ATU (Formal), 2025, N/D
1099, "La 9 – La Banchero", ET. Luis Banchero Rossi S.A. (LUBARSA), Villa María del Triunfo, Jesús María, N/D, ATU (Formal), 2025, N/D
1100, "La P", ET. Urbano Línea 4 S.A. (ETUL4SA), Villa María del Triunfo, Huaycán, N/D, ATU (Formal), 2025, N/D
1107, "La C", ET. Nuevo Horizonte S.A., Villa El Salvador, Lima (Cercado), N/D, ATU (Formal), 2025, N/D
1117, N/D, *Sin operador (ver Ruta 1001)*, N/D, N/D, N/D, N/D, N/D, N/D
1118, N/D, *Sin operador (ver Ruta 1002)*, N/D, N/D, N/D, N/D, N/D, N/D
1139, N/D, Translima S.A. / ET. Urb. Línea 4 S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1170, N/D, Perla Argentina S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1182, N/D, ET. Pacific International S.A. (ETRASERPI), N/D, N/D, N/D, ATU (Formal), 2025, N/D
1183, N/D, ET. Los Ángeles del Perú S.A.C. (ETRAPERSAC), N/D, N/D, N/D, ATU (Formal), 2025, N/D
1194, N/D, ET. Unión San Juanito S.A. / ATCRSA, N/D, N/D, N/D, ATU (Formal), 2025, N/D
1282, N/D, ET. Pacific International S.A. (ETRASERPI), N/D, N/D, N/D, ATU (Formal), 2025, N/D
1289, N/D, Starlet Consorcio S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1294, N/D, ET. Nuevo Perú S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1393, N/D, Líder Pamplona Alta S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1413, N/D, ET. Unidos Chama S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1430, N/D, ET. & Serv. San Felipe S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1439, N/D, ET. 18 de Enero S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1468, N/D, ET. Virgen de la Puerta S.A. / ET. Los Alizos S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D
1489, N/D, ET. Los Alizos S.A., N/D, N/D, N/D, ATU (Formal), 2025, N/D

# En proceso de formalizar

Código (plan), Nombre/Alias, Empresa Operadora, Origen (Distrito), Destino (Distrito), Calles Principales, Tipo Autorización, Fecha (plan/permiso), Flota Vehicular
1001, "Ruta verde San Borja–San Isidro", **Sin operadora (ruta planificada)**, Santiago de Surco, San Isidro, Av. Primavera / Av. Gálvez Barrenechea / Av. Canaval y Moreyra, En trámite (Plan ATU), Feb 2025, 47 (42+5 reserva)
1002, "Ruta verde Callao–Lima Centro", **Sin operadora (ruta planificada)**, La Punta (Callao), La Victoria (Lima), Av. Colonial / Av. Nicolás de Piérola, En trámite (Plan ATU), Feb 2025, N/D
*(Otros 20+ recorridos existentes en Lima/Callao cuyas empresas estaban concluyendo la formalización ante ATU a mediados de 2025)*, , , , , , En trámite (ext. permiso mun.), 2025, N/D

# Incorporados ATU